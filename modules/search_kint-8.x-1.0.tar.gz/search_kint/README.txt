Search Kint extends the devel module.

FUNCTIONALITY:
==============

Search:
-------
You can search for keys or values.

Variable path:
--------------
You can copy the path to an item in an array/object.
Example: $variables['page']->node->nid
