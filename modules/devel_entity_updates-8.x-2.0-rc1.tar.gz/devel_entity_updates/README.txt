Devel Entity Updates
--------------------

This module defines a Drush command aiming to replace the legacy "drush entup"
or "drush entity-updates" commands, however "drush updb --entity-updates" is no
longer supported.
